#include <iostream>
#include <fstream>
#include <string>
#include <map>
using namespace std;

class ItemTracker {
private:
    map<string, int> itemMap;

public:
    // Constructor to load data from the input file
    ItemTracker() {
        LoadItemsFromFile("CS210_Project_Three_Input_File.txt");
    }

    // Load items from input file and populate itemMap
    void LoadItemsFromFile(string filename) {
        ifstream file(filename);
        string item;

        if (file.is_open()) {
            while (file >> item) {
                itemMap[item]++;
            }
            file.close();
        }
        else {
            cout << "Unable to open file!" << endl;
        }
        SaveToFrequencyFile(); // Save the data to frequency.dat as a backup
    }

    // Save item frequencies to frequency.dat
    void SaveToFrequencyFile() {
        ofstream outFile("frequency.dat");
        for (const auto& pair : itemMap) {
            outFile << pair.first << " " << pair.second << endl;
        }
        outFile.close();
    }

    // Return the frequency of a specific item
    int GetItemFrequency(string item) {
        if (itemMap.find(item) != itemMap.end()) {
            return itemMap[item];
        }
        else {
            return 0; // If item is not found
        }
    }

    // Print all items and their frequencies
    void PrintAllItems() {
        for (const auto& pair : itemMap) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    // Print the histogram of item frequencies
    void PrintHistogram() {
        for (const auto& pair : itemMap) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; i++) {
                cout << "*";
            }
            cout << endl;
        }
    }
};

int main() {
    ItemTracker tracker;
    int choice;
    string item;

    do {
        // Display menu options
        cout << "1. Search for item frequency" << endl;
        cout << "2. Display all items with frequency" << endl;
        cout << "3. Display histogram of items" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            // Search for item frequency
            cout << "Enter item name: ";
            cin >> item;
            cout << item << " frequency: " << tracker.GetItemFrequency(item) << endl;
            break;
        case 2:
            // Display all items with their frequencies
            tracker.PrintAllItems();
            break;
        case 3:
            // Display histogram
            tracker.PrintHistogram();
            break;
        case 4:
            cout << "Exiting program." << endl;
            break;
        default:
            cout << "Invalid choice. Try again." << endl;
        }

    } while (choice != 4);

    return 0;
}
